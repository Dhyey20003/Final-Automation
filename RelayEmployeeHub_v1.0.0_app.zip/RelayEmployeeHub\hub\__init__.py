"""Relay Employee Hub: local employee records, photo management and headshot packages."""

APP_NAME = "Relay Employee Hub"
APP_VERSION = "1.0.0"
